class Agenda {
  final String nombre;
  final String control;

  Agenda({required this.nombre, required this.control});
}
// TODO Implement this library.