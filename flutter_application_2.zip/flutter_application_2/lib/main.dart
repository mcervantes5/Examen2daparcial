import 'package:flutter/material.dart';
import 'agenda.dart'; // Asegúrate de tener este archivo también

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Oculta la etiqueta de depuración
      title: 'Agenda',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AgendaScreen(),
    );
  }
}

class AgendaScreen extends StatefulWidget {
  @override
  _AgendaScreenState createState() => _AgendaScreenState();
}

class _AgendaScreenState extends State<AgendaScreen> {
  final List<Agenda> _contactos = [];
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _controlController = TextEditingController();

  void _agregarContacto() {
    if (_nombreController.text.isEmpty || _controlController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Por favor, complete todos los campos')),
      );
      return;
    }

    setState(() {
      _contactos.add(Agenda(
        nombre: _nombreController.text,
        control: _controlController.text,
      ));
      _nombreController.clear();
      _controlController.clear();
    });
  }

  void _verAgenda() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ContactListScreen(contactos: _contactos)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Agenda')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nombreController,
              decoration: InputDecoration(labelText: 'Nombre Completo'),
            ),
            TextField(
              controller: _controlController,
              decoration: InputDecoration(labelText: 'No. Control'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _agregarContacto,
              child: Text('Agregar'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _verAgenda,
              child: Text('Ver Agenda (${_contactos.length})'),
            ),
          ],
        ),
      ),
    );
  }
}

class ContactListScreen extends StatelessWidget {
  final List<Agenda> contactos;

  ContactListScreen({required this.contactos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Listado de Contactos')),
      body: ListView.builder(
        itemCount: contactos.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(contactos[index].nombre),
            subtitle: Text('No. Control: ${contactos[index].control}'),
          );
        },
      ),
    );
  }
}
